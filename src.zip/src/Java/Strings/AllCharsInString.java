package Java.Strings;

import java.util.*;

public class AllCharsInString {
    public static void main(String[] args) {
        String str = "easiest";
        Map<Character, Integer> map = new HashMap<>();

        char[] ch = str.toCharArray();

        for (char c : ch) {
            map.put(c, map.getOrDefault(c, 0) + 1);
        }

        // To print all Chars with count
        System.out.println("All Chars in a given String -- > " + map);

        for(Map.Entry<Character, Integer> entry:map.entrySet())
        {
            System.out.println(entry.getKey() + "-->" + entry.getValue() );
        }


        //To Print Repeating Chars with count

        for (Map.Entry<Character, Integer> entry : map.entrySet()) {
            if (entry.getValue() > 1) {
                System.out.println(entry.getKey() +" --> "+ entry.getValue());
//                System.out.println("The Char "+ entry.getKey()+" is repeating for " + entry.getValue()+ " times given String");
            }
        }

        //To Print Non Repeating Chars with count
        for (Map.Entry<Character, Integer> entry : map.entrySet()) {
            if (entry.getValue() == 1) {
                System.out.println(entry.getKey() +" --> "+ entry.getValue());
//                System.out.println("The Char " + entry.getKey() + " is not repeating in a given string " + entry.getValue());
            }
        }

        //To get first non repeating char

        char first = ' ';

        for (char c : ch) {
            if (map.get(c) == 1) {
                first = c;
                break;
            }
        }
        System.out.println(first);
//        System.out.println("The First Non Repeating Char in a given String -- > " + first);

        //To Print Sec Non Repeating Char

        char firstchar=' ';
        char secchar= ' ';

        for(char c:ch)
        {
            if(map.get(c)==1)
            {
                if(firstchar==' ')
                {
                    firstchar=c;
                }
                else
                {
                    secchar=c;
                    break;
                }
            }
        }

        System.out.println(secchar);
//        System.out.println("The Second Non Repeating Char in a given String -- > " +secchar);


        //To Print Last Non Repeating Char

        for (int i=ch.length-1;i>=0;i--)
        {
            char c=ch[i];
            map.put(c,map.getOrDefault(c,0)+1);
        }

        char lastchar=' ';
        for (int i=ch.length-1;i>=0;i--){
            char c=ch[i];
            if(map.get(c)==1)
            {
                lastchar=c;
                break;
            }
        }
        System.out.println(lastchar);
//        System.out.println("The Last Non Repeating Char in a given String -- > " +lastchar);
    }
}
