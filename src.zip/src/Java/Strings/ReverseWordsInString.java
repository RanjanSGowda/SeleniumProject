package Java.Strings;

public class ReverseWordsInString {
    public static void main(String[] args) {
        String word =" I like Cricket";
        String[] output=word.split(" ");

        for (int i=output.length-1;i>=0;i--)
        {
            System.out.print(output[i] + " ");
        }
    }
}
