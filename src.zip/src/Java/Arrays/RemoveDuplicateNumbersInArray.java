package Java.Arrays;

import java.util.Arrays;
import java.util.Set;
import java.util.TreeSet;

public class RemoveDuplicateNumbersInArray {
    public static void main(String[] args) {
        int[] arr = {1, 2, 2,2,3,22,5,6,7,8,8,5,33,2};
        int len = arr.length;
        int j = 0;

        //Method 1
        Set<Integer> set=new TreeSet<>();

        for(int n:arr)
        {
            set.add(n);

        }

        System.out.println(set);

        //method 2
        Arrays.sort(arr);
        for (int i = 1; i < len; i++) {
            if (arr[i] != arr[j]) {
                j++;
                arr[j] = arr[i];
            }
        }

        int[] result = Arrays.copyOf(arr, j + 1);
        System.out.println(Arrays.toString(result));

    }
}
